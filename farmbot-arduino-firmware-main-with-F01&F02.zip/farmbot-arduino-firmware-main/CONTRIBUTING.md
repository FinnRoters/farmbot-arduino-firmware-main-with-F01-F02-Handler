To get started, <a href="https://www.clahub.com/agreements/FarmBot/farmbot-arduino-firmware">sign the Contributor License Agreement</a>.
