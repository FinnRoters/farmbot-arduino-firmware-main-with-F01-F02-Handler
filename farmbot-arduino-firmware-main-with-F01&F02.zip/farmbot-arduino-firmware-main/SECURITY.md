# Security Policy

## Supported Versions

Please see our [official support policy](http://support-policy.farm.bot).

## Reporting a Vulnerability

Please see our [guidelines for responsibly disclosing security vulnerabilities](http://vulnerabilities.farm.bot/).
