/*
 * GCodeHandler.cpp
 *
 *  Created on: 15 maj 2014
 *      Author: MattLech
 */

#include "GCodeHandler.h"

GCodeHandler::GCodeHandler()
{
}

GCodeHandler::~GCodeHandler()
{
}

int GCodeHandler::execute(Command *)
{
  return -1;
}
